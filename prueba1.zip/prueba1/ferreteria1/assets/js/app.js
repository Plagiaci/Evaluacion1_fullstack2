const PRODUCT_XLSX_FILE = 'datos/DSY1104 - Forma E - Catalogo Ferreteria Los Maestros.xlsx';

const productGrid = document.getElementById('productGrid');
const categoryList = document.getElementById('categoryList');
const searchInput = document.getElementById('searchInput');
const resultCount = document.getElementById('resultCount');
const categoryCount = document.getElementById('allCount');
const totalProductStats = document.getElementById('totalProductStats');
const totalCategoriesStats = document.getElementById('totalCategoriesStats');
const offerCountStats = document.getElementById('offerCountStats');
const heroProductCount = document.getElementById('heroProductCount');
const heroProductCategory = document.getElementById('heroProductCategory');
const sortCategory = document.getElementById('sortCategory');
const toast = document.getElementById('toast');
const cartTotalItems = document.getElementById('cartTotalItems');
const cartTotalPrice = document.getElementById('cartTotalPrice');

let products = [];
let selectedCategory = 'Todos';
let cart = [];
let sortAsc = true;

function normalizeText(text) {
    if (!text && text !== 0) return '';
    return String(text).trim().toLowerCase();
}

function findHeaderValue(row, aliases = []) {
    const availableKeys = Object.keys(row);
    for (const alias of aliases) {
        const exactKey = availableKeys.find(key => normalizeText(key) === normalizeText(alias));
        if (exactKey) return row[exactKey];
    }
    return '';
}

function productIcon(category = '') {
    const cats = normalizeText(category);
    if (cats.includes('electric') || cats.includes('energia') || cats.includes('ilumin')) return '⚡';
    if (cats.includes('herramient') || cats.includes('manual') || cats.includes('mecan')) return '🔧';
    if (cats.includes('pintura') || cats.includes('acabado')) return '🎨';
    if (cats.includes('seguridad')) return '🛡️';
    if (cats.includes('torn') || cats.includes('ferreter')) return '🔩';
    return '🧰';
}

function categoryNameFromDescription(category = '') {
    if (!category) return 'Otros';
    const cat = String(category).trim();
    return cat.charAt(0).toUpperCase() + cat.slice(1);
}

function parseProductsFromXlsx(data) {
    const workbook = XLSX.read(data, { type: 'array' });
    const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(firstSheet, { defval: '', raw: false });

    if (!rows || rows.length === 0) {
        return [];
    }

    const columns = Object.keys(rows[0]);
    const categories = new Set();
    const parsed = [];

    rows.forEach((row, index) => {
        const code = normalizeText(findHeaderValue(row, ['codigo', 'codigo producto', 'id', 'producto'])) || `PRODUCT-${index + 1}`;
        const name = findHeaderValue(row, ['producto', 'nombre', 'descripcion', 'descripcion producto', 'articulo', 'detalle']) || `Producto ${index + 1}`;
        const category = findHeaderValue(row, ['categoria', 'categoría', 'linea', 'clasificacion', 'grupo', 'departamento']) || 'General';
        const brand = findHeaderValue(row, ['marca', 'fabricante']) || 'Ferretería Los Maestros';
        const unit = findHeaderValue(row, ['unidad', 'u.', 'presentacion', 'medida']) || 'unidad';
        const description = findHeaderValue(row, ['descripcion', 'detalle', 'observaciones']) || name;
        const price = Number.parseFloat(findHeaderValue(row, ['precio', 'precio unitario', 'precio venta', 'valor']) || '0');
        const stock = Number.parseInt(findHeaderValue(row, ['stock', 'cantidad', 'existencias']) || '0', 10);

        const safeName = normalizeText(name) ? String(name).trim() : `Producto ${index + 1}`;
        const safeCategory = normalizeText(category) ? String(category).trim() : 'General';

        categories.add(safeCategory);

        parsed.push({
            id: code || `${safeCategory}-${index + 1}`,
            name: safeName,
            category: categoryNameFromDescription(safeCategory),
            brand,
            unit,
            description: description || safeName,
            price: Number.isFinite(price) ? price : 0,
            stock: Number.isFinite(stock) ? stock : 0,
            imageIcon: productIcon(safeCategory)
        });
    });

    return parsed;
}

function currency(value) {
    return new Intl.NumberFormat('es-ES', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 2
    }).format(value || 0);
}

function renderCategories(productList) {
    const categories = ['Todos'];
    productList.forEach(product => {
        if (!categories.includes(product.category)) {
            categories.push(product.category);
        }
    });

    categoryList.innerHTML = '';

    const allButton = document.createElement('button');
    allButton.type = 'button';
    allButton.className = 'category-btn active';
    allButton.dataset.category = 'Todos';
    allButton.innerHTML = `<span class="category-dot"></span><span>Todos</span><span class="category-count" id="allCount">${productList.length}</span>`;
    categoryList.appendChild(allButton);

    categories.slice(1).forEach(category => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'category-btn';
        btn.dataset.category = category;
        btn.innerHTML = `<span class="category-dot"></span><span>${category}</span><span class="category-count">${productList.filter(p => p.category === category).length}</span>`;
        categoryList.appendChild(btn);
    });

    document.querySelectorAll('[data-category]').forEach(btn => {
        btn.addEventListener('click', () => {
            selectedCategory = btn.dataset.category;
            document.querySelectorAll('[data-category]').forEach(item => item.classList.toggle('active', item === btn));
            renderProducts();
        });
    });
}

function renderProducts() {
    const query = normalizeText(searchInput.value);
    const filtered = products.filter(product => {
        const categoryMatch = selectedCategory === 'Todos' || product.category === selectedCategory;
        const queryMatch = !query || normalizeText(product.name).includes(query) || normalizeText(product.description).includes(query) || normalizeText(product.category).includes(query);
        return categoryMatch && queryMatch;
    });

    if (filtered.length === 0) {
        productGrid.innerHTML = `<div class="empty-state">No encontramos productos con esos filtros.</div>`;
        resultCount.textContent = '0 productos';
        return;
    }

    const sorted = [...filtered].sort((a, b) => sortAsc ? a.name.localeCompare(b.name) : b.name.localeCompare(a.name));

    productGrid.innerHTML = sorted.map(product => {
        const isLowStock = product.stock <= 5;
        return `<article class="product-card">
            <div class="product-image">
                <svg viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M4 14l5-5 4 4 7-7" fill="none" stroke="currentColor" stroke-width="2" />
                    <path d="M4 4h16v16H4z" fill="none" stroke="currentColor" stroke-width="2" />
                </svg>
            </div>
            <span class="product-category">${product.category}</span>
            <h3 class="product-title">${product.name}</h3>
            <p class="product-description">${product.description}</p>
            <div class="product-meta">
                <span class="brand">${product.brand}</span>
                <span class="separator">•</span>
                <span class="stock ${isLowStock ? 'low' : ''}">${product.stock} ${product.unit}</span>
            </div>
            <div class="product-footer">
                <span class="product-price">${currency(product.price)}</span>
                <button class="product-add" type="button" data-add="${product.id}" title="Agregar al carrito">+</button>
            </div>
        </article>`;
    }).join('');

    resultCount.textContent = `${filtered.length} ${filtered.length === 1 ? 'producto' : 'productos'}`;
    document.querySelectorAll('[data-add]').forEach(button => {
        button.addEventListener('click', () => addToCart(button.dataset.add));
    });
}

function addToCart(productId) {
    const product = products.find(item => item.id === productId);
    if (!product) return;

    cart.push(product);
    const totalItems = cart.length;
    const totalPrice = cart.reduce((sum, item) => sum + item.price, 0);

    cartTotalItems.textContent = totalItems;
    cartTotalPrice.textContent = currency(totalPrice);

    showToast(`${product.name} agregado`);
}

function showToast(message) {
    const toastMsg = document.querySelector('.toast-message');
    toastMsg.textContent = message;

    toast.classList.add('visible');
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => toast.classList.remove('visible'), 1800);
}

function initStats(productList) {
    totalProductStats.textContent = productList.length;
    totalCategoriesStats.textContent = [...new Set(productList.map(product => product.category))].length;
    offerCountStats.textContent = productList.filter(product => product.price < 50).length;
    heroProductCount.textContent = `${productList.length} productos`;
    heroProductCategory.textContent = selectedCategory;
}

async function loadCatalog() {
    try {
        const response = await fetch(PRODUCT_XLSX_FILE);
        if (!response.ok) {
            throw new Error('No se pudo cargar el archivo Excel.');
        }

        const data = await response.arrayBuffer();
        products = parseProductsFromXlsx(data);
        if (!products.length) {
            productGrid.innerHTML = `<div class="empty-state">El archivo Excel no tiene productos válidos.</div>`;
            return;
        }

        renderCategories(products);
        renderProducts();
        initStats(products);
        categoryCount.textContent = products.length;
    } catch (error) {
        productGrid.innerHTML = `<div class="empty-state">No se pudo cargar el catálogo desde el archivo Excel.</div>`;
        console.error(error);
    }
}

searchInput.addEventListener('input', renderProducts);

sortCategory.addEventListener('click', () => {
    sortAsc = !sortAsc;
    renderProducts();
});

document.getElementById('clearFilters').addEventListener('click', () => {
    searchInput.value = '';
    selectedCategory = 'Todos';
    document.querySelectorAll('[data-category]').forEach(item => item.classList.toggle('active', item.dataset.category === 'Todos'));
    renderProducts();
});

loadCatalog();
