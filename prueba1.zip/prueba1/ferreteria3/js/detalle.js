const idProducto=localStorage.getItem("productoSeleccionado");
const producto=buscarProductoPorId(idProducto);

const ficha=document.getElementById("fichaProducto");
const mensajeSinProducto=document.getElementById("productoNoEncontrado");

if(producto===undefined){
    mensajeSinProducto.classList.remove("d-none");
}else{
    mostrarProducto(producto);
}

function mostrarProducto(producto){
    const imagen=document.getElementById("ferreteria-img");

    document.getElementById("tipoProducto").textContent=producto.tipo;
    document.getElementById("nombreProducto").textContent=producto.nombre;
    document.getElementById("marcaProducto").textContent=producto.marca;
    document.getElementById("precioProducto").textContent=producto.precio;
    document.getElementById("fechaProducto").textContent=producto.fechaCompra;
    document.getElementById("compradorProducto").textContent=producto.comprador;

    ficha.classList.remove("d-move");
}