const contenedor=document.getElementById("listaProductos");
const mensajeSinProducto=document.getElementById("sinProductos");

const producto=obtenerProducto();

if(producto.lenght===0){
    mensajeSinProducto.classList.remove("d-none");
}else{
    producto.forEach(function(producto){
        crearCardProducto(producto);
    });
};

function crearCardProducto(producto){
    const columna=document.createElement("div");
    columna.className="col-md-6 col-lg-4";

    const card=document.createElement("article");
    card.className="card product-card h-100 border-0 shadow-sm";
    card.tabIndex=0;

    const cuerpo=document.createElement("div");
    cuerpo.className="card-body p-4";

    const imagen=document.createElement("img");
    imagen.className="ferreteria-img mb-3";

    const nombre=document.createElement("h2");
    nombre.className="h5 mb-1 text-center";
    nombre.textContent=producto.nombre;

    const marca=document.createElement("p");
    marca.className="text-secondary mb-0 text-center";
    marca.textContent=producto.marca;

    cuerpo.appendChild(imagen);
    cuerpo.appendChild(nombre);
    cuerpo.appendChild(tipo);
    card.appendChild(cuerpo);
    columna.appendChild(card);
    contenedor.appendChild(columna);
};

function abrirDetalle(id){
    localStorage.setItem("productoSeleccionado",id);
    window.location.href="detalle.html";

    card.addEventListener("click",function(){
        abrirDetalle(producto.id);
    });
};