const formulario = document.getElementById("formProducto");
const mensajeRegistro=document.getElementById("mensajeRegistro");

function mostrarError(mensaje){
    mensajeRegistro.textContent=mensaje;
    mensajeRegistro.classList.remove("d-none");
    mensajeRegistro.classList.remove("alert-success");
    mensajeRegistro.classList.add("alert-danger");
};

function mostrarExito(mensaje){
    mensajeRegistro.textContent=mensaje;
    mensajeRegistro.classList.remove("d-none");
    mensajeRegistro.classList.remove("alert-danger");
    mensajeRegistro.classList.add("alert-success");
};

formulario.addEventListener("submit", function (evento) {
    evento.preventDefault();

    const nombre = document.getElementById("nombre").value;
    const tipo = document.getElementById("tipo").value;
    const marca = document.getElementById("marca").value;
    const precio = document.getElementById("precio").value;
    const fechaCompra = document.getElementById("fechaCompra").value;
    const comprador = document.getElementById("comprador").value;

    if(nombre.trim() === ""){
        mostrarError("El nombre no puede quedar vacío");
        return;
    }

    if(marca.trim() === ""){
        mostrarError("La marca no puede quedar vacía");
        return;
    }

    if(comprador.trim() === ""){
        mostrarError("El comprador no puede quedar vacío");
        return;
    }

    if(precio === ""){
        mostrarError("El precio no puede quedar vacío");
        return;
    }

    if(Number(precio) <= 0){
        mostrarError("El precio no puede ser menor que 0");
        return;
    }

    if(fechaCompra === ""){
        mostrarError("La fecha de compra no puede quedar vacía");
        return;
    }

    const nuevoProducto = {
        id: crypto.randomUUID(),
        nombre,
        tipo,
        marca,
        precio,
        fechaCompra,
        comprador
    };

    agregarProducto(nuevoProducto);
    mostrarExito("Producto registrado con éxito");
    formulario.reset();
});
