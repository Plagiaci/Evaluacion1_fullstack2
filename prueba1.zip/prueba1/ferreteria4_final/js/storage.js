const CLAVE_PRODUCTO = "ferreteria_productos";

function obtenerProducto(){
    const datos = localStorage.getItem(CLAVE_PRODUCTO)
    if (datos === null) return []
    return JSON.parse(datos)
};
function guardarProducto(producto){
    const productosJSON = JSON.stringify(producto);
    localStorage.setItem(CLAVE_PRODUCTO, productosJSON);
};
function agregarProducto(nProducto){
    const productos = obtenerProducto();
    productos.push(nProducto);
    guardarProducto(productos);
};
function buscarProductoPorId(id){
    const producto=obtenerProducto();
    return producto.find(function(producto){
        return producto.id===id;
    });
};