const contenedor=document.getElementById("listaProductos");
const mensajeSinProducto=document.getElementById("sinProductos");

const producto=obtenerProducto();

if(producto.length === 0){
    mensajeSinProducto.classList.remove("d-none");
}else{
    producto.forEach(function(producto){
        crearCardProducto(producto);
    });
};

function crearCardProducto(producto){
    const columna=document.createElement("div");
    columna.className="col-md-6 col-lg-4";

    const card=document.createElement("article");
    card.className="card product-card h-100 border-0 shadow-sm";
    card.tabIndex=0;

    const cuerpo=document.createElement("div");
    cuerpo.className="card-body p-4";

    const imagen=document.createElement("img");
    imagen.className="ferreteria-img mb-3";
    if(producto.tipo==="Herramienta"){
        imagen.src = "img/herramienta.png";
        imagen.alt = producto.nombre;
    } else if(producto.tipo==="Pinturas"){
        imagen.src = "img/cubo-de-pintura.png";
        imagen.alt = producto.nombre;
    } else if(producto.tipo==="Gasfitería") {
        imagen.src = "img/plomeria.png";
        imagen.alt = producto.nombre;
    } else if(producto.tipo==="Electricidad"){
        imagen.src = "img/electricidad.png";
        imagen.alt = producto.nombre;
    } else if(producto.tipo==="Tornillería"){
        imagen.src = "img/tornillo.png";
        imagen.alt = producto.nombre;
    } else if(producto.tipo==="Madera"){
        imagen.src = "img/tablero.png";
        imagen.alt = producto.nombre;
    } else if(producto.tipo==="Jardín"){
        imagen.src = "img/jardineria.png";
        imagen.alt = producto.nombre;
    } else if(producto.tipo==="Seguridad"){
        imagen.src = "img/casco.png";
        imagen.alt = producto.nombre;
    } else {
        imagen.src = "img/construccion.png";
        imagen.alt = producto.nombre;
    }

    const nombre=document.createElement("h2");
    nombre.className="h5 mb-1 text-center";
    nombre.textContent=producto.nombre;

    const tipo=document.createElement("p");
    tipo.className="text-secondary mb-0 text-center";
    tipo.textContent=producto.tipo;

    cuerpo.appendChild(imagen);
    cuerpo.appendChild(nombre);
    cuerpo.appendChild(tipo);
    card.appendChild(cuerpo);
    columna.appendChild(card);
    contenedor.appendChild(columna);

    card.addEventListener("click", function() {
    abrirDetalle(producto.id);
    });
};

function abrirDetalle(id){
    localStorage.setItem("productoSeleccionado",id);
    window.location.href="detalle.html";
};
