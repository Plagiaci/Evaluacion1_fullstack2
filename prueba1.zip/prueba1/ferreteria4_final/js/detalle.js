const idProducto=localStorage.getItem("productoSeleccionado");
const producto=buscarProductoPorId(idProducto);

const ficha=document.getElementById("fichaProducto");
const mensajeSinProducto=document.getElementById("productoNoEncontrado");

if(producto===undefined){
    mensajeSinProducto.classList.remove("d-none");
}else{
    mostrarProducto(producto);
}

function mostrarProducto(producto){
    const imagen=document.getElementById("ferreteria-img");

    document.getElementById("tipoFerreteria").textContent = producto.tipo;
    document.getElementById("nombreFerreteria").textContent = producto.nombre;
    document.getElementById("marcaProducto").textContent = producto.marca;
    document.getElementById("precioProducto").textContent = producto.precio;
    document.getElementById("fechaCompra").textContent = producto.fechaCompra;
    document.getElementById("comprador").textContent = producto.comprador;

    ficha.classList.remove("d-none");
}